package com.example.DevopsProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevopsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
